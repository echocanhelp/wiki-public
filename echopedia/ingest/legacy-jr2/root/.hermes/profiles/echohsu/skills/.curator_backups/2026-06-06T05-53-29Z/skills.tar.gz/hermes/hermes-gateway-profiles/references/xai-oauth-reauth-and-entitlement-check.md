# xAI OAuth Re-auth + Entitlement Verification (2026-05)

## Trigger
Use this workflow when:
- LINE webhook transport is healthy (ngrok + `/line/webhook/health` OK)
- Hermes completions fail with upstream 403/502 indicating credits/subscription
- User reports they *do* have an active Grok subscription

## Key finding
`hermes login --provider xai-oauth` is deprecated in this environment. The correct re-auth path is now under `hermes auth`.

## Verified recovery sequence

1. Remove current xAI OAuth state:
```bash
hermes --profile echohsu logout --provider xai-oauth
# or
hermes --profile echohsu auth logout xai-oauth
```

2. Start OAuth add flow:
```bash
hermes --profile echohsu auth add xai-oauth --type oauth --no-browser
```
- CLI prints an authorization URL and waits for callback on loopback.

3. Complete browser auth using printed URL.

4. Validate profile token binding (email/account):
- Read `~/.hermes/profiles/<name>/auth.json`
- Decode `id_token` payload and confirm expected user email.

5. Validate upstream entitlement directly (bypassing bridge):
- `GET https://api.x.ai/v1/models` with Bearer access token
- `POST https://api.x.ai/v1/chat/completions`

6. Decision:
- If direct xAI calls still return subscription/credit 403, escalate as xAI entitlement/billing issue.
- Do not continue port/ngrok churn when entitlement check fails.

## Notes
- In this case, token email matched expected account, but both `/models` and `/chat/completions` still returned entitlement 403.
- Distinguish clearly:
  - Bridge/network problem: webhook or health endpoints fail.
  - Upstream entitlement problem: bridge healthy, direct provider calls denied.
