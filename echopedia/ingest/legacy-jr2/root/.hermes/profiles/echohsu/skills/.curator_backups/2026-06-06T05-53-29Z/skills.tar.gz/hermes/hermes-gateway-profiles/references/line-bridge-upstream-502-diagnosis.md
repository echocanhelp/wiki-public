# LINE Webhook Healthy but Response Fails: Upstream 403→502 Pattern

## When to use
Use this when:
- LINE webhook endpoint is active
- ngrok tunnel is up and points to Hermes LINE adapter (`127.0.0.1:8646`)
- `/line/webhook/health` returns healthy
- but user still sees fallback text like "please try again later"

## Verified discriminator workflow
1. Check adapter health (`/line/webhook/health`) and ngrok tunnel target.
2. Call Hermes API directly at `/v1/chat/completions` with valid API server bearer token.
3. Use profile model id (`echohsu`) instead of hardcoded upstream model names.
4. Inspect error payload:
   - `502` wrapper with embedded upstream `403` credit/subscription message indicates provider exhaustion, not bridge failure.

## Concrete signal from this session
Hermes returned:
- HTTP `502` from local API server
- Embedded upstream error: permission denied due to out-of-credits / subscription requirement

## Remediation order
1. Restore provider credits/subscription, or
2. Temporarily switch profile/provider routing to a working backend.

Avoid repeated restarts/port changes once this signature is confirmed.