---
name: line-platform-adapter
category: devops
description: Debugging and patching the Hermes LINE Messaging API adapter, especially MessageType enum mismatches and non-text message handling.
tags: [line, messaging, adapter, debugging, platform]
---

# LINE Platform Adapter

Handles debugging, patching, and maintenance of the Hermes LINE Messaging API adapter (`hermes_plugins.line_platform.adapter`).

## Core Responsibilities
- Diagnose webhook dispatch failures in LINE group and DM contexts
- Fix `MessageType` enum mismatches (e.g. `IMAGE` vs `PHOTO`)
- Ensure non-text messages (photos, stickers, locations) are handled without crashing `_handle_message_event`
- Maintain compatibility between LINE webhook events and the core `MessageEvent` / `MessageType` model

## Known Pitfalls
- The LINE adapter hardcodes `MessageType.IMAGE` in several places. The actual enum in `gateway.platforms.base` uses `PHOTO`, `VIDEO`, `AUDIO`, etc. This mismatch causes immediate `AttributeError` on any non-text message.
- Group chat lifecycle events (join/leave) can trigger message handling paths before the adapter is fully initialized.
- Image handling is particularly fragile because LINE uses a separate content download endpoint.

## Debugging Pattern
1. Search gateway.log for the group/chat ID + recent `dispatch_event failed` errors.
2. Extract the traceback — almost always points to line ~972 in adapter.py (`MessageType.IMAGE`).
3. Confirm the enum members via `python -c "from gateway.platforms.base import MessageType; print(MessageType.__members__)"`.
4. Apply minimal patch: replace `MessageType.IMAGE` → `MessageType.PHOTO`.

## References
- `references/message-type-enum.md` — Current MessageType enum members and LINE webhook msg_type values
- `references/common-crash-patterns.md` — Typical error signatures when the adapter receives images in groups

## When to Load
Load this skill whenever LINE sessions become unresponsive to photos, stickers, or other non-text content, or when `AttributeError: IMAGE` appears in gateway.log.