---
name: echopedia-homepage-curator
description: Daily automation to refresh the Echopedia homepage with a rotating selection of Featured People and Institutional Memory pages.
category: devops
---

# Echopedia Homepage Curator

This skill powers the daily refresh of the Echopedia main page (`index.md`).

## Current Behavior (v1)

- Scans all person pages (`*-*.md`) in `/root/wiki-public/content`
- Ranks them by:
  - Total line count (depth)
  - Last modified time (recency)
- Selects the top 6 people pages
- Selects 4 strong institutional / project pages (hardcoded for v1)
- Updates the "Featured People" and "Featured Institutional Memory" sections in `index.md`
- Syncs the change to the deploy repo and pushes

Note: Repetition avoidance is intentionally disabled in v1 due to limited historical data.

## Files Modified

- `/root/wiki-public/content/index.md`
- `/root/wiki-deploy/content/index.md`

## Future Improvements (v2+)

- Add repetition avoidance using a "recently featured" log
- Add tag-based weighting
- Add LINE/Telegram notification after refresh
- Make institutional selection dynamic

## Usage

This skill is designed to be called by a daily cron job (see `cronjob` configuration).