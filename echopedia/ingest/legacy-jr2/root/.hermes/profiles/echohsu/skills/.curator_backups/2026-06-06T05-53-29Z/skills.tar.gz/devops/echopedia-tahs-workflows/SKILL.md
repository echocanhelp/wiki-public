---
name: echopedia-tahs-workflows
category: devops
description: Class-level umbrella for Echopedia and TAHS (Taiwanese American Historical Society) research, person documentation, manual research workflows, and society document consolidation.
---

# Echopedia & TAHS Workflows (Umbrella)

Class-level skill covering all workflows for building, researching, and publishing Echopedia pages focused on Taiwanese American individuals, organizations, and the TAHS society.

## Core Principles (shared across all sub-workflows)
- Always use bilingual naming: English (Chinese characters) or Chinese (Romanization).
- Never publish personal contact information.
- Consolidate TAHS documents into ONE canonical society page.
- Prefer primary sources, community documents, and user-provided raw search text over automated scraping when blocked.
- Maintain Draft/Published status correctly; Drafts are intentionally visible for review.

## Subsections

### Manual Research Workflow (from echopedia-manual-research-workflow)
Workflow for building person and organization pages when automated tools hit CAPTCHA or return no Chinese results. Process user-provided raw Google search text, extract structured facts (elections, roles, publications, events), cross-reference timelines, produce bilingual entries with Sources section.

### Person Research Workflow (from echopedia-person-research)
Research workflow prioritizing primary documents, community newsletters, government records for Taiwanese American biographical sources. Chinese name search conventions, source prioritization, pitfalls around Google scraping and English-only names.

### TAHS Documentation Workflow (from tahs-echopedia-documentation)
Ingest and publish TAHS governance/historical documents into a single consolidated page (`taiwanese-american-historical-society-台美人歷史協會.md`). Naming conventions, content hygiene, publishing flow to wiki-deploy, Draft policy for client review.

## When to Load
Load this umbrella whenever working on Echopedia person pages, TAHS society content, or any Taiwanese American historical documentation tasks.

## Related Skills
- wiki-maintenance (for general wiki QA, broken links, deploy)
- public-wiki-intake-publishing-qa (for intake form hygiene)

## References / Support Files
Place session-specific detail, reproduction recipes, and source excerpts under `references/`.
