---
name: wiki-maintenance
category: devops
description: Quality assurance, deduplication, broken-link fixing, and rebuild workflow for the Echo System public wiki (Quartz v1.0.0).
---

# Wiki Maintenance

Quality assurance, deduplication, broken-link fixing, and rebuild workflow for the Echo System public wiki (source content at `/root/wiki-public/`, deployment repo at `/root/wiki-deploy/`, deployed to `echocanhelp.github.io/wiki-public`).

## Trigger

- "fix the wiki", "clean up backlinks", "rebuild wiki", "broken links", "dedup links", "wiki audit", "deploy wiki"
- "update website" / "publish now" / "push live" (fast deploy trigger)
- Before expanding wiki with new content, run a fidelity pass first (quality over quantity)
- External-source enrichment requests (Wikipedia/community sites/source books/PDFs) for wiki pages

## Absorbed: External Enrichment Workflow (from `wiki-enrichment`)

This skill is the class-level umbrella for both maintenance and enrichment of `/root/wiki-public/content/`.

- Build/enrich pages from external sources (Wikipedia, community org sites, historical source texts)
- Treat orphaned index links as actionable: if link exists in index but file is missing, create the page
- Keep enrichment conservative and well-linked: prefer 2-4 strong cross-links over broad speculative expansion
- For broad source ingestion, follow phased "hub page → core entities → support pages → indexes → broken-link scan"

Critical editing guardrails absorbed:
- Never overwrite existing rich pages with stubs
- Verify whether target file exists before creating/replacing content
- Prefer additive edits and section-level patching for existing pages

### Fast Deploy Trigger: "Update website"

When the user asks to update/publish the website after content work, run a direct deploy path without extra back-and-forth:

1. `cd /root/wiki-deploy && git fetch origin && git pull --ff-only origin master`
2. `rsync -av --delete /root/wiki-public/content/ /root/wiki-deploy/content/`
3. `git add -A && git commit -m "Wiki update: ..." && git push origin master`
4. Verify live endpoint returns HTTP 200: `curl -I -L https://echocanhelp.github.io/wiki-public/`

Report success with commit hash and live URL. If there are no staged changes, report "already up to date" explicitly.

## Workflow

### 1. Deduplicate Links Within Files

Same entity linked multiple times in a single file creates duplicate backlinks in Quartz's bottom-of-page backlinks section.

Run the dedup script:

```bash
python3 /root/.hermes/profiles/echohsu/skills/devops/wiki-maintenance/scripts/dedup-links.py
```

This keeps only the **first** `[[link]]` or `[[link|display]]` per target in each file, converting subsequent occurrences to plain display text.

### 2. Scan for Broken Cross-References

Find `[[links]]` that point to non-existent pages:

```bash
python3 /root/.hermes/profiles/echohsu/skills/devops/wiki-maintenance/scripts/scan-broken-links.py
```

**Fix strategy (in priority order):**
1. **Redirect** — Point to existing equivalent page: `[[old]]` → `[[existing-page]]`
2. **Create** — Make new page if entity is core to the Taiwanese American community
3. **Convert to plain text** — For tangential/external references (e.g. "University of Hawaii at Manoa", "Asian American Studies")

### 3. Check for Symlink Loops

Quartz build fails with `ELOOP: too many symbolic links` if a symlink creates a cycle. Diagnose:

```bash
find /root/wiki-public/content -type l -ls
```

Known bad symlink: `content/content -> ../content` — remove with `rm /root/wiki-public/content/content`

### 4. Rebuild and Deploy

**First: identify the active deployment repo (do not assume path).**

In this environment, content may exist in `/root/wiki-public/content/` while the actual GitHub Pages deployment repo is `/root/wiki-deploy/` (remote `echocanhelp/wiki-public`). Always verify the repo that has `.git` + `.github/workflows/deploy.yml` before committing.

Quick check:
```bash
find /root -maxdepth 3 -type d -name .git
```
### 4. Rebuild and Deploy

Current split:
- **Source workspace**: `/root/wiki-public/content/` (authoring)
- **Deployment repo**: `/root/wiki-deploy/` (GitHub remote `echocanhelp/wiki-public`)

**Choose sync mode intentionally:**
- **Targeted publish (preferred for single-page updates):** copy only changed files to avoid unrelated bulk publishes.
  ```bash
  cp /root/wiki-public/content/<changed-file>.md /root/wiki-deploy/content/
  ```
- **Full mirror publish:**
  ```bash
  rsync -av --delete /root/wiki-public/content/ /root/wiki-deploy/content/
  ```

**Mandatory scope check before commit:**
```bash
git -C /root/wiki-deploy status --short
```
If unrelated files appear, stop and either (a) switch to targeted copy, or (b) explicitly confirm you're doing a full-batch deploy.

**Deploy via git push** (site deploys automatically via GitHub Actions on push to `master`):
```bash
cd /root/wiki-deploy
git add -A && git commit -m "Wiki maintenance: ..."
git push origin master
```

Then wait ~60s for GitHub Actions deploy and verify `https://echocanhelp.github.io/wiki-public/`.

Note: this repo's CI build copies `index.md` into Quartz content; if homepage unexpectedly returns RSS/XML, confirm workflow still includes that copy step.

### 5. Verify Deployment

Navigate to `https://echocanhelp.github.io/wiki-public/` and check:
- Backlinks sections are deduplicated (no same entity appearing multiple times on one page)
- No broken link 404s
- Graph view is clean
- **Homepage featured links resolve** (click each Featured Content link from the live homepage and confirm it does not return 404)

Homepage link-path rule (critical):
- In deployment repo `/root/wiki-deploy/index.md`, do **not** link featured pages as `content/<slug>.md`.
- Use Quartz-friendly paths like `<slug>` (e.g. `toward-a-community-of-hope`, `albert-s-lai`) so generated links resolve under `/wiki-public/` without `/content/...` 404s.
- **Homepage Featured Content links resolve** (click each featured link from `/` and ensure non-404)

## Page Creation Convention

When creating new wiki pages:
- **Frontmatter**: `type:` + `tags:` (always include "Taiwanese American" + 2-3 specific tags)
- **Title**: `# English Name (中文名)` — Chinese characters AND romanized form required per CORE DIRECTIVE
- **Wiki links**: `[[category/Name-中文名|Display Name]]` — first occurrence linked, subsequent mentions plain text
- **Length**: 3-5 sections max per page
- **Cross-links**: Link to 2-4 related existing pages
- **Directory**: `person/`, `organization/`, `location/`, `event/`, `award/`, `publication/`, `language/`, `concept/`
- **Never ask permission** to create pages — just do it (CORE DIRECTIVE)

### TAHS Society Page Consolidation Rule (new)
When the user uploads multiple TAHS organizational documents (roster, bylaws, IRS letter, action items, multi-year plans) and says any variation of **"Use the existing page for the historical society"**, **always consolidate** everything into **one single canonical page** for 台美人歷史協會.

Do not create separate pages for each document type. Append new material under appropriate sections on the unified society page. This is a user-enforced workflow preference for TAHS governance material.

### Person-page standard (testimony-centered)
For `type: person` pages, do not stop at a short bio. Use testimony-centered historical recordation:
- Include a **Testaments / Voice** section with direct quotes (or explicitly marked attributed summaries when quotes are unavailable)
- Each testimony item should include: date/period, context (sermon/interview/preface/speech), and source note
- Include **Community Context** (institutional setting + historical moment + relationship links)
- Include **Contributions and Legacy** with concrete claims tied to source notes
- Include **Source & Confidence** notes (primary vs retrospective distinction)
- End with a contribution invitation (family memory, colleague testimony, photos/documents, corrections)

Use `references/person-recordation-playbook.md` for the full structure/template.

## Content Sourcing from Google Docs

When the user provides a Google Docs link for wikification (common for historical dissertations, books, and personal manuscripts):

1. Prefer the direct export endpoint over browser navigation:
   ```
   https://docs.google.com/document/d/DOCUMENT_ID/export?format=txt
   ```
   This returns clean plain text even when the document is view-only and browser tools struggle with dynamic canvas/iframe rendering.

2. Save to a temporary file first:
   ```bash
   curl -sL "https://docs.google.com/document/d/ID/export?format=txt" > /tmp/source.txt
   ```

3. Then read in chunks with `read_file` (offset + limit) to analyze structure, chapters, and front matter before wikifying.

4. Always preserve both English and Chinese titles/sections when present.

This pattern is especially useful for TAHS historical documents and 1970s–80s Taiwanese American church materials.

## Content Sourcing from Google Drive PDFs (new default fallback)

When source material is a Google Drive PDF (not a Google Doc), use this sequence:

1. Locate folder/file IDs with Google Workspace CLI wrapper:
   ```bash
   python3 ${HERMES_HOME:-$HOME/.hermes}/skills/productivity/google-workspace/scripts/google_api.py drive search "name contains 'KEYWORD' and mimeType = 'application/vnd.google-apps.folder' and trashed = false" --raw-query --max 20
   python3 ${HERMES_HOME:-$HOME/.hermes}/skills/productivity/google-workspace/scripts/google_api.py drive search "'FOLDER_ID' in parents and mimeType = 'application/pdf' and trashed = false" --raw-query --max 100
   ```

2. If only file metadata is available (no direct download command), download bytes via Python Drive API using the existing profile token (`/root/.hermes/profiles/echohsu/google_token.json`) and `files().get_media(fileId=...)`.

3. Extract text locally with PyMuPDF and persist to `/tmp/*.txt` for chunked reading.

4. Build/expand wiki pages from extracted text using structural sections (timeline, chapter map, themes, related entities), then run broken-link scan before finishing.

Why this matters: Drive search is sufficient to discover IDs, but historical-book wikification requires a deterministic file-byte download + local extraction step when the wrapper lacks `drive download`. This pattern should be preferred over brittle browser/manual download flows.

## Fidelity Before Expansion

**User preference: fix existing content quality before adding new entries.** When asked to expand the wiki, first run a fidelity pass (dedup + broken links + symlink check) then expand. Exclude entities not directly relevant to the Taiwanese American community.

## Scripts

- `scripts/dedup-links.py` — Deduplicate [[wiki links]] within files
- `scripts/scan-broken-links.py` — Find all broken wiki links

## References

- `references/historical-book-wikification.md` — Recommended structure and workflow for wikifying full historical books and dissertations (e.g. 1971 Albert Lai D.Min. work)
- `references/historical-source-cluster-expansion.md` — Phase-based method for turning one historical source into a richly linked wiki cluster (hub page + people/org/location/concept satellites + validation loop)
- `references/gstpc-domain-phased-expansion-playbook.md` — Domain-wide church-site ingestion pattern (inventory → narrative digests → structured entry indexes → quality hardening → fiduciary provenance) with CI verification gates.
- `references/gstpc-phase-intent-replication-playbook.md` — Phase intent/procedure/deliverable/exit-gate template (A→E) for reproducible future website ingestions.
- `references/source-adaptive-ingest-and-person-wikification.md` — Source-type adaptive ingest policy and bulletin person-wikification prioritization pattern.
- `references/person-authenticity-pass.md` — Testimony-first person-page upgrade workflow: replace attributed summaries with direct quotes, attach source provenance, and deploy with link verification.

## Person-Page Authenticity Pass (Testimony-First)

When a book/source cluster includes people pages, run an explicit authenticity pass after initial page creation.

1. Build or locate a quote bank from source text (book forewords, prefaces, reflections, signatures, interviews).
2. Prefer direct first-person quotations over paraphrased/attributed summaries.
3. For each testimony block, include:
   - Date/period
   - Context (section name or document context)
   - Source pointer (page/line/doc path)
   - Source tier (A/B/C)
4. If OCR text is noisy, preserve the quote with minimal normalization and add a provenance note.
5. Create a cluster-level testimony source page (e.g., `...-republication-voices-and-testaments`) and link all person pages to it.
6. Re-run broken-link scan before reporting completion.

Quality rule: if direct quote exists in available source material, do not leave only attributed-summary testimony on the person page.

### Phase-4 tracker and normalization pattern (new)

When running person-page upgrade waves (e.g., "Go phase 4"), use this deterministic sequence:

1. **Scope only real person pages** by frontmatter `type: person` (do not include template/concept pages just because tags mention `person`).
2. Build/refresh a tracker table with three checks per page:
   - has testimony section
   - has source notes section
   - has A-tier signal
3. Upgrade pages in two passes:
   - Pass A: add missing testimony structure + contribution invitation
   - Pass B: authenticity pass replacing attributed summaries with direct quotations where available
4. Normalize source-confidence wording across person pages:
   - prefer `Source Notes and Confidence`
   - include a compact A-tier/B-tier/C-tier legend
   - keep tier labels consistent (`A-tier`, `B-tier`, `C-tier`)
5. Re-run broken-link scan and deploy; verify live 200 for tracker + sampled upgraded pages.

Pitfall: automated page discovery that matches `tags: person` can accidentally include template pages (e.g., person-page template). For trackers and rollout metrics, use `type: person` as the canonical filter.
## Historical Source Cluster Expansion (Phase Pattern)

## Book Chapterization Pattern (new default for long-form works)

When converting a full historical book/dissertation into Echopedia pages, use this deterministic structure:

1. Create/verify the **hub page** (book-level metadata + significance + toolkit links).
2. Create **7 chapter nodes** (Chapter I–VI + Conclusion) as separate pages using a consistent schema:
   - Chapter summary
   - Why chapter matters for TAHS
   - Analytical frame/model
   - Key entities
   - Key concepts
   - Source excerpts + interpretive notes
   - Research notes (explicit 1971 vs 2025 layer separation when applicable)
   - Suggested follow-up pages
   - Related pages
3. Upgrade the chapter index into a **navigation panel** (not just a list):
   - "How to use this index"
   - Priority reading paths (e.g., migration path / church-formation path / identity-theology path)
   - Quick navigation matrix by research intent
4. Update hub chapter list to deep-link to each chapter page.
5. Run broken-link scan immediately after chapter creation and again after index upgrades.

Why this matters: chapterization creates reusable graph nodes for people/org/concept extraction and avoids overloading one monolithic book page.

When the user asks to "continue" expanding from a single source (book/dissertation/PDF), use this repeatable phase pattern:

1. Build/upgrade the **hub page** first (bibliography, chapter map, significance, research utility).
2. Create **high-confidence core entities** next (author + primary orgs/churches/institutions).
3. Add **historiography support pages** (timeline, source-critical notes, terminology/translation notes, primary-source extracts).
4. Add **navigation indexes** (people-network map, places/institutions index).
5. Expand mention-only names into pages only when role/context can be stated conservatively from source text.
6. Normalize naming variants (e.g., romanization variants) with explicit disambiguation notes on the canonical page.
7. After each phase, run broken-link validation before reporting completion.

Quality rule: prefer incremental enrichment + dense internal linking over long single-page dumps.
- `references/google-drive-pdf-wikification-playbook.md` — End-to-end workflow for Drive PDF discovery/download, extraction, phased wiki expansion, disambiguation, and link verification

## Audio Companion Workflow (Chapter/Book Pages)

When user asks to add an audiobook/voice companion to a wiki page (especially historical chapters):

1. Create a dedicated consent + recording kit page first (template + spoken consent + recording specs + attribution policy).
2. Link that kit from the target chapter page under an "Audiobook" or "Audio Production" section before outreach begins.
3. **Source-fidelity gate (mandatory before TTS):** verify you are narrating the primary chapter text, not a wiki summary/analysis page.
   - If given a Drive file URL, download the source bytes first and extract text to `/tmp`.
   - Locate explicit chapter boundary markers (e.g., `CHAPTER I ...` to `CHAPTER II ...`) and narrate only that bounded segment.
   - If boundaries are ambiguous, stop and ask for canonical chapter text rather than guessing.
4. Prefer high-quality direct recordings (WAV, quiet room, 16k/24k+) for voice modeling; treat telephony (Twilio call audio) as coordination-quality, not primary training-quality.
5. Use Twilio/SMS/phone primarily for outreach, scheduling, and explicit written consent confirmation, not as the main sample corpus.
6. Run a short pilot clip QA gate (pronunciation, pacing, artifacts) before producing full chapter audio.
7. Add publication metadata on-page: narrator attribution, consent status/date, audio version/date, and source-confidence note.
8. After generation, publish via a dedicated audiobook page and link it from both the chapter node and the book hub page.

- `references/audiobook-voice-capture-workflow.md`
- `references/audiobook-source-fidelity-checklist.md` — Prevent narrating summary pages by mistake; chapter-boundary extraction and verification checklist
- `references/quartz-build-failure-frontmatter-triage.md` — Local reproduction workflow for CI build failures, YAML frontmatter parse-error fixes, and post-rsync scope checks.

## Main-Page Link Audit Playbook (Homepage)

When user asks to "check all links on main page and repair":

0. **Featured-ingestion rule (new):** homepage Featured Content must include current primary ingestion target(s) (for example, newly ingested source domains/books) so major completed ingestion work is visible from `/`.
1. **Homepage contact block rule (new):** if user provides official public contact info, add/update a dedicated `## Contact` section on homepage (`index.md`) with exact canonical formatting and verify after deploy.

1. Audit the live homepage URL first: `https://echocanhelp.github.io/wiki-public/`.
2. Prefer a dependency-light checker (Python `requests` + regex href extraction) instead of BeautifulSoup, since bs4 may be unavailable.
3. Validate all discovered links, but classify results:
   - **User-facing content links** (e.g., featured pages) must return non-404 and are repair targets.
   - **Preconnect/resource-hint domains** (e.g., `fonts.googleapis.com`, `fonts.gstatic.com` root URLs) can return 404 when opened directly and should not be treated as broken content links.
4. If featured links are broken, repair `/root/wiki-deploy/index.md` and ensure links use Quartz-friendly routes (slug paths, not `/content/...`).
5. **Classify Google links by type before publishing**:
   - `docs.google.com/document/...` = Google Doc (document text)
   - `docs.google.com/spreadsheets/...` = Google Sheet
   - `forms.gle/...` or `docs.google.com/forms/.../viewform` = live Google Form
   Never label a Doc link as a live intake form.
6. **Public-access check for contributor-facing links**:
   - For public hub pages, keep only links that anonymous visitors can open (target HTTP 200 for form/page endpoints).
   - Move internal/private ops links (intake queue sheets, internal templates, staff docs) off public pages or clearly mark them internal.
7. Re-check live links after changes and report exactly what was fixed vs. already healthy.

## Person-Page Rollout Safeguards (Phase-style bulk updates)

When applying cross-cutting updates to many person pages (e.g., adding contribution-hub links, testimony upgrades), use these safeguards:

1. Build target list from raw file IO (Python `open`) or a non-decorated reader. Avoid readers that prepend line numbers or truncate aggressively during classification checks.
2. Do not trust a single file-search page when `truncated=true` appears; paginate with `offset` or walk the directory recursively to avoid partial target sets.
3. Scope edits strictly to real person records:
   - require `type: person` in frontmatter, OR
   - `tags` includes `person`
   - and explicitly exclude template/framework/index concept pages (e.g., `*template*`, `*framework*`, tracker/index utilities).
4. After batch edits, run broken-link scan before deploy, then live-check both homepage and at least one newly-created/updated target page.

Why this matters: bulk operations can silently miss pages (partial listing) or accidentally mutate non-person utility pages if selection rules are too loose.

## Phase 4 Person-Page Rollout Pattern (Contribution Hub + Tracker)

When user says "Go phase 4" after testimony-centered person-page work:

1. **Roll out contribution-hub link to all person pages**
   - Ensure each `type: person` page contains a `Contribution Invitation` section linking:
     - `[[echopedia-community-contributions-hub|Echopedia Community Contributions Hub]]`
   - If section missing, add a standardized invitation block.

2. **Create/update a testimony-upgrade tracker page**
   - Use a dedicated index page (e.g., `echopedia-person-pages-testimony-upgrade-tracker`) with status columns:
     - Testimony section present
     - Source notes present
     - A-tier/direct-quote signal present
   - Status classes: `Ready`, `Needs authenticity pass`, `Needs testimony structure`.

3. **Important scope rule for tracker accuracy**
   - Tracker should include only true person pages (`type: person`).
   - Do **not** include concept/template pages just because body text contains `- person` examples (e.g., person-page templates).

4. **Phase 4.1 execution order**
   - First eliminate `Needs testimony structure` (add full testimony-centered skeleton).
   - Then run authenticity pass on remaining pages to upgrade B/C summaries to A-tier direct quotes where source permits.

5. **After each batch**
   - Run broken-link scan.
   - Deploy and verify live 200 for homepage + tracker + at least one upgraded person page URL.

## Build-Failure Triage Pattern (GitHub Pages / Quartz)

When a push deploys to GitHub but the new page stays 404, treat it as possible CI build failure before re-editing content.

1. Check latest workflow run status via GitHub API (`/actions/runs?per_page=1`) and confirm the head SHA/conclusion.
2. If the latest run failed, reproduce locally with the same Quartz workflow sequence used in CI:
   - clone Quartz version used by deploy workflow
   - copy `quartz.config.ts`, `quartz.layout.ts`, `index.md`, and `content/*`
   - run `node quartz/bootstrap-cli.mjs build`
3. Fix the first parser/build error found, then redeploy and re-check workflow conclusion = success before live URL validation.

### YAML frontmatter parser pitfall (high-frequency)
Quartz frontmatter parsing can fail on flow-style YAML arrays when values include bracket-like tokens (example: `evidence.issues[0]`).

Use block-style YAML lists with quoted strings instead of flow arrays for such fields.

Preferred safe pattern:

```yaml
source:
  - "evidence.checks.utc_now"
  - "evidence.issues[0]"
```

Avoid:

```yaml
source: [evidence.checks.utc_now, evidence.issues[0]]
```

## GSTPC-style Domain Expansion + Per-Entry Backfill Pattern (new)

## Source-Adaptive Ingest Policy (websites vs books vs other literature)

When ingesting external sources into Echopedia, choose workflow by source type instead of forcing a single stub/template path.

1. **Websites (URL pages, bulletin archives):**
   - Preserve meaningful source text first (excerpt or normalized block) before summarization.
   - Never publish a shallow stub when source page is rich.
   - Keep one primary official source URL in metadata; avoid repetitive outbound link spam in body text.
   - Prefer internal Echopedia links for context/navigation.

2. **Books / PDFs / dissertations:**
   - Use hub + chapter/section nodes; preserve narrative evidence and context.
   - Person-page creation requires role/context evidence, not name-only mention.

3. **Other literature/document forms (Docs/reports/transcripts):**
   - Preserve original structure/headings where possible.
   - Include source-confidence notes when extraction quality is uncertain.

### Richness gate (anti-stub rule)

Force full-enrichment mode (not stubs) when any condition is true:
- source text is substantial,
- multiple people/entities are present,
- scripture/event/date signals are present,
- or the page belongs to a historically important recurring archive series.

### Link hygiene gate

Before publish:
- deduplicate repeated identical external links within a page,
- keep outbound links intentional (one canonical source reference is usually enough),
- ensure internal cross-links carry most navigation load.

### Bulletin-heavy person wikification pattern

For sources like church bulletins with frequent person mentions:
1. Build a candidate index from repeated mentions across entries.
2. Prioritize by evidence tiers (high-frequency + clear role context first).
3. Canonicalize bilingual variants (Chinese/romanized/English) into one person record.
4. Keep source-note backlinks to specific bulletin entries for traceability.
## GSTPC-style Domain Expansion + Per-Entry Backfill Pattern (new)

When a user asks for full-domain wiki coverage plus "don't stop" continuation:

1. Work in explicit phases and publish each phase before moving on:
   - Phase 1: domain page inventory
   - Phase 2: timeline/chronology digest pages
   - Phase 3: structured entry-index tables
   - Phase 4: per-entry page rollout (year-scoped first, then all-years backfill)
2. Build a tracker page for each rollout wave (year tracker + all-years tracker) and link trackers from the domain index hub.
3. For large backfills, generate pages programmatically into year subdirectories (e.g., `gstpc-bulletins/2025/...`) to keep navigation predictable and prevent filename collisions.
4. After each deploy push, verify GitHub Actions status before claiming success; if run fails, fix and repush before continuing next phase.
5. Verify representative live URLs across multiple years/categories (not just newest pages) to catch routing/path issues early.

## Phase-D Quality Hardening Pattern (website ingest)

Use this when source pages are rich and the user explicitly wants preservation quality over shallow stubs.

## Public Wiki Intake Publishing QA (absorbed from public-wiki-intake-publishing-qa)

QA workflow for publishing community intake pages on a public wiki without exposing private ops links or mislabeling non-live submission URLs.

**Core goals**
- Public page only contains contributor-safe links.
- Claims like “live form” are validated by URL type and HTTP behavior.
- Internal ops links stay off public pages.
- Deploy + verify before reporting success.

**Required workflow**
1. Interpret concise intake commands as execute-now.
2. Anchor to the latest explicit user request.
3. Classify every link before publish (forms.gle = live form; docs.google.com/forms/.../viewform = live; internal sheets/docs = ops).
4. Block internal links from public page; move ops links to private runbooks.
5. Verify “live form” claim by confirming it resolves as a form (not a template doc).
6. For historical archive enrichment, build year-aware pages + index pages with provenance.
7. Deploy safely using the two-repo pattern (wiki-public → wiki-deploy) and post-deploy validation.
8. Run link check and flag only user-facing failures.

**Pitfalls**
- Marking a Google Doc as a live Google Form.
- Leaving private/internal Google Docs/Sheets on public contribution pages.
- Reporting “live” before validating rendered site content after deploy.

See original references/echopedia-contributions-hub-rollout.md and gstpc-historical-bulletin-rollout-pattern.md for detailed rollout sequences.

1. Add a **Richness Gate** before page creation/update:
   - If source text is substantial or carries multiple entities/signals, block stub output.
2. Add a **Structured Schema v2** layer on top of preserved excerpt:
   - sermon title
   - speaker
   - scripture block count
   - announcement/intercession flags
   - date/event tokens
3. Add a **Confidence Gate** for person promotion:
   - Promotion-ready: high confidence + high mention breadth
   - Watchlist: medium confidence or moderate breadth
   - Verification-needed: ambiguous aliases / low confidence
4. Add a **Link Hygiene Audit** page for repetitive outbound URLs and keep one canonical external source reference per page.
5. Refresh index pages with confidence/status columns and include “last run” style QA notes.

## Ambiguous Alias Handling (Phase C.1 pattern)

When repeated English-only aliases appear in bulletins (e.g., "Brother X"):

1. Create an alias-draft index page with evidence samples.
2. Create **verification-needed evidence-only person stubs** (no biography claims).
3. Link those stubs from the rollout queue and candidate index.
4. Do not canonical-merge until bilingual/canonical identity is confirmed.
5. Keep claims conservative and source-note anchored.

5. Verify representative live URLs across multiple years/categories (not just newest pages) to catch routing/path issues early.
6. When freshly-added pages 404 immediately after a successful Actions run, re-check sitemap and wait/retry (short propagation lag can occur before pages return 200).

### Phase B extraction guardrails (web bulletin archives)

- Use page-level mention counts (dedupe within each page) for people/scripture stats; avoid raw token frequency inflation.
- Scripture extraction must filter time-pattern noise (`at 10:00`, `from 11:00-11`, etc.).
- Extract from preserved source-capture text, not only prefilled `Detected` blocks.
- Regenerate both the historical-signals index and person-candidate index from the same normalized pass.

### Phase C person-wikification guardrails

- Create a canonical alias map first (Chinese + English + title variants merged only when confidence is high).
- Filter non-person/noisy tokens before queueing (role phrases, OCR fragments, generic labels).
- Build a strict Tier-A queue (`>=20` page mentions after filtering) for immediate person-page action.
- Prefer upgrading existing canonical person pages with bulletin evidence sections before creating duplicates.
5. Verify representative live URLs across multiple years/categories (not just newest pages) to catch routing/path issues early.

### Phase-C person extraction extension (GSTPC bulletin style)

When bulletin/entity expansion reaches person-wikification phases:

1. Build a **canonical alias map** first (Chinese + English + title variants), and explicitly list known merges.
2. Split outputs into:
   - **Tier-A canonical queue** (high-confidence identities, create/upgrade now)
   - **verification-needed stubs** for ambiguous aliases (e.g., "Brother X") with evidence-only scope.
3. For verification-needed stubs, enforce strict guardrails:
   - no speculative biography claims
   - include mention counts + sample source links
   - add explicit "identity unresolved" status and upgrade criteria.
4. Cross-link map ↔ queue ↔ stubs so future passes can resolve identities incrementally without losing evidence.

### GitHub Pages propagation lag check (post-success 404 handling)

After a successful Actions deploy, newly-added pages can still return transient 404s for several polling cycles. Do not treat immediate 404 as failure when CI is green.

Use this sequence:
1. Confirm latest workflow run conclusion = `success` for the pushed SHA.
2. Poll target URLs with retry/backoff for at least ~90 seconds before declaring failure.
3. Optionally confirm `sitemap.xml` includes new slugs during propagation.
4. Report final verification only after URLs return 200.

## Frontmatter YAML Safety Rule (critical)

Quartz frontmatter parsing is strict YAML. Avoid flow-style arrays with unquoted tokens containing brackets (e.g., `evidence.issues[0]`) because they can break build parsing.

Preferred safe pattern:
- Use block-style lists
- Quote entries that contain punctuation/brackets/dots

Example safe form:

```yaml
source:
  - "evidence.checks.utc_now"
  - "evidence.issues[0]"
```

## Pitfalls

- **Quartz build ELOOP**: Symlink at `content/content -> ../content` causes infinite loop. Always run `find /root/wiki-public/content -type l -ls` before rebuild. **Fix: `rm` can TIMEOUT on symlinks — use Python instead:** `python3 -c "import os; os.unlink('/root/wiki-public/content/content')"`
- **Default Quartz config leak**: if `quartz.config.ts` still has `pageTitle: "Quartz 4"` or `baseUrl: "quartz.jzhao.xyz"`, the site/feed can look like Quartz demo output. Set `baseUrl` to `echocanhelp.github.io/wiki-public` and use TAHS/Echopedia title before deploy.
- **Repo drift**: local deployment clones can be behind remote; run `git fetch` + `git pull --ff-only` before edits to avoid patching stale workflow/config state.
- **Dedup is highest-impact first step**: `organizations-taiwanese-americans.md` typically has 16+ duplicate links. The dedup script handles this automatically.
- **Firecrawl out of credits**: Fall back to `web_search` or skip research-heavy expansion
- **Alias variations**: `[[NTPC]]` and `[[organization/NTPC]]` both resolve to same target — normalize to full path
- **Sync marker**: `.sync_marker.md` is a technical file, ignore its broken links
- **Quartz Graph page is /graph**: Returns 404 if `Plugin.Graph()` emitter not enabled in `quartz.config.ts`
- **Homepage Featured links can 404 if index.md uses `/content/...` URLs**: On this Quartz deployment, featured links on `/` must point to valid site routes (typically relative links like `toward-a-community-of-hope` / `albert-s-lai`, not hardcoded `/wiki-public/content/...`). Always click-test featured links after deploy.
- **Homepage link-check false positives**: when auditing `/`, raw `href` sweeps include technical preconnect/provider domains (e.g., `fonts.googleapis.com`, `fonts.gstatic.com`) that can return 404 when fetched directly. Do not treat these as broken user-facing links; prioritize validating featured content and internal navigation links.
- **Portable homepage audit method**: if BeautifulSoup/bs4 is unavailable, use Python `re` + `urllib.parse.urljoin` + `requests` to extract and validate links. This avoids dependency failures and keeps maintenance checks runnable on minimal environments.
- **GitHub Pages deploy failed but content push succeeded**: when a new page remains 404 after push, check latest Actions run conclusion first (success/failure) before re-editing content. If failed, isolate build-blocking files by reproducing Quartz build locally with the same workflow sequence (`clone quartz`, copy config/content, run `node quartz/bootstrap-cli.mjs build`).
- **Frontmatter YAML hazard**: avoid flow-style arrays when values contain bracket-like tokens (for example `evidence.issues[0]`). Prefer block-style YAML lists with quoted strings to prevent parser failures that stop the entire site build.
- **Subagent timeouts on research**: web_search + file creation tasks can timeout at 600s. Keep research scopes narrow, delegate one entity per subagent
- **Audiobook source mismatch risk**: chapter wiki nodes are often summaries, not canonical text. Never narrate chapter pages directly when the request is "book chapter audio" — extract and boundary-check against the primary source (PDF/Doc) first.
