---
name: public-wiki-intake-publishing-qa
description: QA workflow for publishing community intake pages on a public wiki without exposing private ops links or mislabeling non-live submission URLs.
version: 1.0.0
author: EchoHsu
license: MIT
---

# Public Wiki Intake Publishing QA

## When to use
Use this skill whenever updating public-facing contribution/intake pages (forms, email, LINE/social submission channels, community hubs).

## Core goals
1. Public page only contains contributor-safe links.
2. Claims like “live form” are validated by URL type and HTTP behavior.
3. Internal ops links stay off public pages.
4. Deploy + verify before reporting success.

## Required workflow
1. **Interpret concise intake commands as execute-now**
   - If user sends `echopedia <url>` (or equivalent terse command), treat it as immediate intake/publish work.
   - Do not stall with permission-seeking; begin capture + publish flow directly.
2. **Anchor to the latest explicit user request before acting**
   - If context was compacted/summarized, ignore prior completion chatter unless the user re-asks for it.
   - For terse commands like `echopedia <url>`, scope work to that specific URL/domain and avoid unrelated carry-over status reports.
3. **Classify every link before publish**
   - Public intake links: `forms.gle/...` or `docs.google.com/forms/d/e/.../viewform`
   - Internal ops links: queue sheets, private docs, internal templates
3. **Block internal links from public page**
   - Do not publish links that require org login for normal contributors.
   - Move ops links to private runbooks/staff docs.
4. **Verify “live form” claim**
   - Confirm the URL is an actual Google Form endpoint (not a Google Doc template).
   - If it is a template doc, label it explicitly as template/setup, not live intake.
5. **Historical archive enrichment when source has dated bulletins/posts**
   - Build/update year-aware pages (not only a single latest-page summary).
   - Add/refresh index pages that connect: source domain page index + historical signal index + rollout tracker.
   - For each archived item, preserve minimum provenance fields: source title, source URL, capture date, excerpt, and cross-links.
6. **Deploy safely (two-repo reality)**
   - Confirm whether the authoring workspace is actually a git repo.
   - If authoring workspace is non-git (e.g., `/root/wiki-public`), copy/sync changed files into the deploy repo (e.g., `/root/wiki-deploy/content/...`) before commit.
   - Commit/push from the actual deploy git repo only.
7. **Post-deploy validation**
   - Check rendered page contains expected public channels (form/email/LINE).
   - Run link check and flag only user-facing failures (ignore non-content resources like font host root URLs).
   - Re-check key intake link resolves successfully.
   - For historical rollouts, verify representative live URLs across multiple years return HTTP 200, plus key index pages.

## Pitfalls
- Marking a Google Doc as a live Google Form.
- Leaving private/internal Google Docs/Sheets on public contribution pages.
- Reporting “live” before validating rendered site content after deploy.
- Assuming deployment failed when CDN/rendering lags briefly; verify both rendered page and raw repo content before re-editing.

## Quick acceptance checklist
- [ ] Live form link resolves and opens a form.
- [ ] Email + messaging channel are present as fallback.
- [ ] No internal spreadsheet/doc links on public page.
- [ ] Deployment pushed and rendered page verified.

## References
- Add session-specific audits under `references/` (link status snapshots, false-positive patterns, rollout notes).
- See `references/echopedia-contributions-hub-rollout.md` for a proven rollout + validation sequence for contributor intake hubs.
- See `references/gstpc-historical-bulletin-rollout-pattern.md` for multi-year bulletin archival structure + representative live verification pattern.
