---
name: media-content-pipeline
description: "Umbrella for media search, extraction, music/audio generation, audio visualization, and YouTube-derived content."
version: 1.0.0
author: Hermes Agent Curator
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [media, youtube, gif, audio, music, spectrogram, transcript, content-repurposing]
---

# Media Content Pipeline

Use this umbrella for media tasks: finding GIFs, extracting YouTube transcripts, converting videos into summaries/posts, generating music/audio, writing song prompts/lyrics, and analyzing audio features.

## Routing

- **YouTube / video links**: fetch transcript when available; fall back to video analysis only when transcript is missing or the visual content matters.
- **GIF search**: use provider APIs/CLI, download only when the user needs a file attachment or local reuse.
- **Songwriting / AI music**: separate lyric craft from model prompt formatting; preserve the user's intended genre, mood, and constraints.
- **Audio generation**: select model/tool family based on whether the desired output is song-with-lyrics, instrumental music, or sound effects.
- **Audio visualization/analysis**: generate spectrograms or features when the user asks about structure, timbre, rhythm, or comparison.

## Procedure

1. Identify input medium, desired output format, and licensing/privacy constraints.
2. Prefer transcript/metadata extraction for summarization; prefer multimodal analysis for visual/audio claims.
3. Produce the requested artifact: file, summary, thread, prompt, spectrogram, or generated media.
4. Verify paths/URLs exist and include enough provenance for reuse.

## Pitfalls

- YouTube transcripts can be auto-generated and imperfect; quote uncertainty when precision matters.
- GIF/media APIs may require keys; report missing credentials rather than fabricating results.
- Music generation prompts should be descriptive but not overloaded with contradictory genre tags.

## Consolidated media subworkflows

### YouTube-derived content
- Fetch transcripts first for summaries, articles, quote extraction, and social threads. Preserve URL, title/channel/date when available, and mark auto-generated transcript uncertainty.
- Use visual/video analysis only when the user asks about on-screen events, demonstrations, or transcript gaps.

### Audio generation and model-backed media
- AudioCraft/MusicGen-style tasks can be routed here when the user wants generated audio as media rather than model-engineering details; return the actual output file path.
- Keep lyrics/songwriting, instrumental prompts, sound effects, and audio analysis as distinct subsections of one media pipeline.