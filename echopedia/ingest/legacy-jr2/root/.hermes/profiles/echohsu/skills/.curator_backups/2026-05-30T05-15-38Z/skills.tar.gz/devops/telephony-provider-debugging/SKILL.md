---
name: telephony-provider-debugging
description: Debug and harden outbound calling pipelines across Twilio, Bland.ai, and Vapi with profile-aware config checks and provider-specific validation.
version: 1.0.0
author: EchoHsu
license: MIT
---

# Telephony Provider Debugging

## When to use
Use this skill when outbound calls are partially working (e.g., Twilio works but AI provider fails), or when provider errors are inconsistent across tools/clients.

## Core workflow
1. **Verify profile-scoped config first**
   - Confirm the active `.env` path is profile-specific (not root/global by accident).
   - Validate provider readiness with a diagnostics command before placing calls.

2. **Split transport vs provider failures**
   - Run a Twilio direct outbound call first to validate number ownership, carrier route, and target reachability.
   - Then run AI-provider call (Bland/Vapi). If AI fails while Twilio succeeds, isolate to provider/API layer.

3. **Reproduce with minimal HTTP probe**
   - Send a minimal API request using the same key and endpoint.
   - Compare behavior across HTTP clients/signatures (headers, user-agent, content-type).

4. **Apply client-compatibility hardening**
   - If provider edge/security blocks default client signature, set an explicit browser-like `User-Agent` in shared request helper.
   - Re-test end-to-end via CLI command path (not only ad hoc script).

5. **Validate voice/resource existence explicitly**
   - Do not assume voice names exist in current account/catalog.
   - Query provider voices list and confirm requested voice before setting defaults.
   - If a voice name fails (`Voice not found`), retry with the provider voice **ID**.

6. **Bland routing isolation (important)**
   - If Bland call is accepted/queued but user reports no ring, fetch `ai-status` immediately.
   - If status resolves to `busy` while a same-minute Twilio baseline call rings, treat this as provider-route/origination-path issue (not handset reachability).
   - Do not keep blind-retrying the same provider path; switch to reliable fallback and escalate with call IDs.

7. **Operational fallback**
   - If AI provider is blocked or route-failing, continue service with Twilio direct calls while triaging provider issue.

## Pitfalls
- "Configured=true" does **not** guarantee provider call success.
- A provider can reject one HTTP signature while accepting another (same API key).
- Voice aliases from other platforms/docs may not exist in current provider account.
- Completed Twilio calls may not always ring user device (carrier filtering/unknown caller behavior); validate with repeated timestamped tests.
- Bland may reject explicit `from` with `Invalid 'from'` even when Twilio number is valid for direct Twilio calls; account/provider-side origination entitlement may differ.
- A queued Bland call can still end `busy`; always verify with `ai-status` before assuming the user missed a ring.

## Verification checklist
- Diagnose output points to intended profile `.env` and state path.
- Twilio direct call succeeds and status transitions (`queued` -> `in-progress`/`completed`).
- AI provider call succeeds with returned call ID.
- Requested voice is confirmed present in provider voice catalog.
- Fallback path documented and runnable.

## References
- `references/bland-cloudflare-1010-and-voice-validation.md` — concrete reproduction and fix pattern for Bland 403/1010 plus voice-not-found handling.
- `references/bland-busy-route-isolation-with-twilio-baseline.md` — diagnosing queued/no-ring calls that resolve to `busy`, plus route isolation and escalation checklist.
