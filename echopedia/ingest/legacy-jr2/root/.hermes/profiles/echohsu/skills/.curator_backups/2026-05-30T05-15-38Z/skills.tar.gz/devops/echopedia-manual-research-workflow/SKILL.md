---
name: echopedia-manual-research-workflow
category: devops
description: Workflow for building Echopedia person and organization pages when automated web search tools are blocked by bot detection or return no usable Chinese results. Focuses on processing user-provided raw Google search text.
---

# Echopedia Manual Research Workflow

## When to Use
- Automated tools (`browser_navigate`, DuckDuckGo, etc.) hit CAPTCHA or fail to return Chinese search results.
- User manually performs Google searches and pastes raw result text.
- Goal is to extract biographical, organizational, and historical facts for Echopedia pages (especially TAHS-related figures).

## Core Process
1. Receive raw Google search result text from user.
2. Extract structured facts only (names, dates, roles, organizations, election results, publications).
3. Ignore unrelated or duplicate entries.
4. Cross-reference across multiple result batches to build timeline and confirm roles.
5. Update or create the target `.md` page with proper bilingual formatting.
6. Commit changes via the wiki-deploy repo.

## Key Extraction Patterns
- Election results: candidate number, vote count, party, year, district.
- Organizational roles: exact title (創會會長, 會長), date of appointment or event.
- Publications: book titles, translation credits, article titles.
- Events: dates, locations, co-participants.

## Pitfalls to Avoid
- Do not attempt further automated searches once user begins providing manual results (wastes tokens and frustrates).
- Do not over-interpret ambiguous name matches (e.g., historical figures with same name).
- Always verify role timelines across multiple result sets before publishing.

## Output Standard
- Always produce clean, bilingual (Chinese + romanized) entries.
- Include `Sources` section when multiple external references are identified.
- Keep status as `Draft` until user explicitly says "publish".