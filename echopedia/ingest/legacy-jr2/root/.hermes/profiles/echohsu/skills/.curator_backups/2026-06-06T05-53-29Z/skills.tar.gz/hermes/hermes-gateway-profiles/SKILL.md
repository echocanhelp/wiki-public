---
name: hermes-gateway-profiles
description: "Managing Hermes Agent multi-profile gateway systemd services, especially handling the special 'default' profile and preventing cross-profile contamination after updates."
version: 1.0.0
category: hermes
---

# Hermes Multi-Profile Gateway Management

## Core Principle
Hermes named profiles (content, orchestrator, echohsu, etc.) work reliably with dedicated `hermes-gateway-<name>.service` files. The special "default" profile has legacy behavior that often ignores `--profile default` and falls back to a generic service.

## Key Patterns

### Dedicated Service File Template
Always create explicit service files for important profiles:

```ini
[Unit]
Description=Hermes Agent Gateway - <Profile> Profile
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/lib/hermes-agent/venv/bin/python -m hermes_cli.main --profile <name> gateway run --replace
WorkingDirectory=/usr/local/lib/hermes-agent
Environment="HERMES_HOME=/root/.hermes/profiles/<name>"
Restart=always
...
```

### Default Profile Gotcha
The `hermes-gateway.service` (used by the default profile) frequently reverts or ignores profile scoping after updates. When this happens:

1. Force-update the service file with correct `--profile default` and `HERMES_HOME`.
2. Use `hermes --profile default gateway stop` then start.
3. If the process still launches generically, consider migrating the primary/home gateway to a named profile instead.

### Debugging Steps
- Check `ps aux | grep hermes_cli.main` for actual command line flags.
- Compare `hermes --profile X gateway status` output (especially "Other profiles" section).
- Review `~/.hermes/profiles/<name>/logs/gateway.log` for "Active profile:" lines.
- Verify service file content after any `gateway start` command.

## LINE Adapter + ngrok Port Triage (Echo Stack)
When LINE webhook traffic suddenly fails after closing a terminal, the common cause is **ngrok down** or **ngrok forwarding to a stale local port**.

Use this fast triage sequence:

1. Confirm live listeners and owning processes (`ss -ltnp`, `ps -fp <pid>`).
2. Native target should be Hermes LINE adapter on `127.0.0.1:8646` (`/line/webhook`).
3. Confirm ngrok target (`curl http://127.0.0.1:4040/api/tunnels`) and compare `config.addr` to `127.0.0.1:8646`.
4. Confirm LINE webhook endpoint registration via LINE API (`/v2/bot/channel/webhook/endpoint`) to avoid changing the wrong layer.
5. If hostname is correct but local forward is wrong, restart ngrok to the adapter port: `127.0.0.1:8646`.
6. If events arrive but are ignored, check allowlists (`LINE_ALLOWED_USERS`, `LINE_ALLOWED_GROUPS`, `LINE_ALLOWED_ROOMS`) and logs for `LINE: rejecting unauthorized source`.
7. If webhook path is healthy but responses fail, run a direct API probe against Hermes (`/v1/chat/completions`) with the profile model id (often `echohsu`) to separate transport failures from upstream model/provider failures.

Legacy custom bridge on `:8765` is optional and should stay disabled unless a specific compatibility requirement exists.

### Pitfall: fallback error text can be upstream quota/auth failure
A healthy webhook path (LINE endpoint + ngrok + adapter health all green) can still return fallback text when Hermes returns 502 due to upstream provider failure.

Fast discriminator:
- `GET /line/webhook/health` succeeds, but
- direct Hermes completion call fails with payload showing upstream `403` credit/subscription/auth error.

When this happens, do **not** keep rotating ports/services. Treat it as provider/billing/routing remediation (credits, subscription, or temporary provider/model switch).

### OAuth CLI migration pitfall (xAI)
Hermes CLI auth flow has migrated: `hermes login` may be unavailable even if legacy docs mention it. For xAI OAuth re-auth, use:

1. `hermes --profile <name> auth logout` (or `logout --provider xai-oauth`)
2. `hermes --profile <name> auth add xai-oauth --type oauth --no-browser`
3. Open returned authorization URL and complete callback
4. Re-test direct xAI API and Hermes `/v1/chat/completions`

Do **not** rely on `hermes login --provider xai-oauth` in remediation runbooks; it can no-op with deprecation text.

### Verify account binding before blaming bridge wiring
If user claims subscription is active but xAI returns 403:
- Decode `id_token` from profile `auth.json` to confirm email/account binding.
- Call xAI endpoint directly with that access token (e.g., `/v1/models`, `/v1/chat/completions`).
- If direct calls return subscription/credits 403, issue is upstream entitlement, not bridge/ngrok.

Common pattern captured: bridge listens on 87xx while Hermes API listens on 86xx; do not confuse backend API port with webhook ingress port.

## Absorbed: General Multi-Profile Operations (from `hermes-profiles`)

This skill is the class-level umbrella for Hermes profile + gateway scoping operations.

Additional principles absorbed:
- **Migration vs activation separation**: moving profile data (config/auth/memory/channels) does not switch the active gateway service; stop/start the target profile explicitly.
- **Dual verification after every state change**:
  1. `ps aux | grep hermes_cli.main | grep gateway`
  2. `hermes --profile <name> gateway status`
  Report both service state and whether process args include the intended `--profile` flag.
- **Primary gateway recommendation**: prefer dedicated named-profile services over relying on default-profile implicit behavior.

## References
See `references/default-profile-issues.md` for session-specific debugging notes from 2026-05.
See `references/line-ngrok-port-recovery.md` for webhook/ngrok mismatch recovery workflow.
See `references/line-bridge-upstream-502-diagnosis.md` for the upstream 403→502 diagnosis pattern and verification sequence.
See `references/xai-oauth-reauth-and-entitlement-check.md` for the 2026-05 CLI migration + entitlement verification sequence.
