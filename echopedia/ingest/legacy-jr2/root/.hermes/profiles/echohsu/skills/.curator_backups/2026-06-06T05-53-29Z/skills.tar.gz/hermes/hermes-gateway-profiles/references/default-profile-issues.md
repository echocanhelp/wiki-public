# Default Profile Gateway Issues (May 2026)

## Observed Behavior
After major multi-profile update, the `default` profile's gateway frequently launches without `--profile default` flag, causing status commands to report it under "Other profiles: content".

## Root Cause Indicators
- `hermes-gateway.service` ExecStart missing `--profile default`
- `HERMES_HOME` pointing to global `/root/.hermes` instead of `/root/.hermes/profiles/default`
- `hermes --profile default gateway start` ignores profile flag in some environments
- Status shows "Active profile: content" in content logs even when default should be primary

## Workarounds Tried
- Repeated service file overwrites
- `pkill` + restart cycles
- Creating `hermes-gateway-default.service`

## Recommended Long-term Fix
Migrate primary/home gateway responsibilities to a named profile (e.g. `echohsu` or a new `primary` profile) rather than relying on the special "default" profile for production gateway work.