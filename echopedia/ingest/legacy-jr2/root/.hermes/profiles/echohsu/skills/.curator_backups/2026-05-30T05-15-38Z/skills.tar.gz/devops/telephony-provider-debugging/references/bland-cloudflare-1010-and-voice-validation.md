# Bland 403/1010 + Voice Validation (Operational Note)

## Scenario
- Twilio direct outbound call worked.
- Bland `ai-call` failed with `HTTP 403` and Cloudflare `error code: 1010`.
- Same Bland key was present and valid.

## Root cause pattern
Provider edge (Cloudflare) blocked default Python `urllib` request signature used by CLI helper, while accepting browser-like client signatures.

## Reproduction recipe
1. Call Bland endpoint with default urllib-style request headers.
2. Observe `403` + `error code: 1010`.
3. Repeat same payload with explicit browser-like `User-Agent`.
4. Observe success (`call queued`).

## Durable fix
In shared JSON request helper, set default header:
- `User-Agent: Mozilla/5.0 (compatible; HermesTelephony/1.0)`

Apply in one central helper so all providers/commands benefit.

## Secondary finding: voice mismatch
After transport fix, Bland call with voice `angie` returned:
- `HTTP 400` -> `{"status":"error","message":"Voice not found"}`

Action:
- Query `/v1/voices` and verify requested voice exists before setting defaults.
- Keep a known-good fallback (e.g., `mason`) for immediate continuity.

## Operational guidance
- Treat this as a two-layer diagnostic:
  1) transport/client signature
  2) provider resource validity (voice IDs/names)
- Keep Twilio direct call as fallback to preserve outbound service while AI provider is triaged.
