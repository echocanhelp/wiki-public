# LINE Native Adapter + ngrok Port Recovery (2026-05, canonical)

## Symptom
- LINE worked previously.
- Restart/terminal closure caused tunnel interruption.
- Group/DM messages stopped reaching Hermes.

## Verified live-state pattern (canonical)
- Native LINE adapter listener: `127.0.0.1:8646` (`/line/webhook` in Hermes gateway)
- ngrok must forward to: `127.0.0.1:8646`
- Common failure: ngrok process absent or targeting stale port
- Additional failure class: source rejected by allowlist (`LINE_ALLOWED_*`)

## Root cause class
Ingress mismatch: webhook hostname exists, but tunnel target or source authorization does not match runtime expectations.

## Deterministic recovery recipe
1. Check listeners and owners:
   - `ss -ltnp | awk 'NR==1 || /:8646|:4040/'`
   - `ps aux | grep -E 'ngrok|hermes_cli.main' | grep -v grep`
2. Check ngrok target:
   - `curl -s http://127.0.0.1:4040/api/tunnels | python -m json.tool`
3. Check webhook registration in LINE:
   - `GET https://api.line.me/v2/bot/channel/webhook/endpoint`
4. Restart ngrok to native adapter target if needed:
   - `/usr/local/bin/ngrok http --config /root/.config/ngrok/ngrok.yml 127.0.0.1:8646`
5. Validate adapter health:
   - `http://127.0.0.1:8646/line/webhook/health`
6. If still no replies, inspect gateway logs for:
   - `LINE: rejecting unauthorized source`
   and allowlist the active `groupId`/`roomId`/`userId` in `.env`.

## Legacy note
Older custom bridge flow (`line_bridge_fresh.py` on `:8765`) is retained only for exceptional compatibility scenarios and is not the default runtime path.
