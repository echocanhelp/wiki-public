# MessageType Enum (as of 2026-05-28)

From `gateway.platforms.base`:

```python
{'TEXT': 'text',
 'LOCATION': 'location',
 'PHOTO': 'photo',
 'VIDEO': 'video',
 'AUDIO': 'audio',
 'VOICE': 'voice',
 'DOCUMENT': 'document',
 'STICKER': 'sticker',
 'COMMAND': 'command'}
```

## LINE Webhook msg_type values vs MessageType mapping

| LINE msg_type | Correct MessageType | Notes |
|---------------|---------------------|-------|
| text          | TEXT                | - |
| image         | PHOTO               | Most common non-text case |
| sticker       | STICKER             | - |
| location      | LOCATION            | - |
| video         | VIDEO               | - |
| audio         | AUDIO               | - |

## Common Crash

```
AttributeError: IMAGE
```

Always occurs at:
```python
message_type=MessageType.TEXT if msg_type == "text" else MessageType.IMAGE
```