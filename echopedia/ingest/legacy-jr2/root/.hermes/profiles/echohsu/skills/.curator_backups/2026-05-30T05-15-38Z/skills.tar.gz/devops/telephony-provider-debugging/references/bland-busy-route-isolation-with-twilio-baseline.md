# Bland queued/no-ring -> busy: route isolation playbook

## Symptom pattern
- `ai-call` returns success with `call_id` (queued).
- User reports no ring.
- `ai-status` later resolves to `busy` (often `answered_by: unknown` or null).

## Proven isolation sequence
1. Place Bland call (voice name or ID) and capture `call_id`.
2. Poll `ai-status` for that call.
3. Immediately place Twilio direct baseline call to same destination.
4. If Twilio rings but Bland ends `busy`, classify as **Bland route/origination issue** for this destination.

## High-signal checks
- Voice catalog mismatch:
  - If voice name fails (`Voice not found`), retry with explicit voice ID.
- Originating number constraints:
  - Explicit `from` may return `Invalid 'from'` even when Twilio number is owned and works for direct Twilio calling.
  - Interpret as provider-side origination entitlement mismatch, not a local config error.

## What to do next
- Keep service running with Twilio direct calls.
- Escalate to Bland support with:
  - affected destination (masked in user-facing logs),
  - failing `call_id`s,
  - timestamps,
  - proof that Twilio baseline succeeds to same target.

## Operator note
Do not keep blind-retrying identical Bland calls after repeated `busy`; switch to fallback and escalate with evidence.