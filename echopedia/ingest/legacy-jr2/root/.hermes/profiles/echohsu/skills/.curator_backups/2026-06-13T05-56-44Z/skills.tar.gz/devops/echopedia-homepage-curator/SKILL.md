---
name: echopedia-homepage-curator
description: Daily automation to refresh the Echopedia homepage with a rotating selection of Featured People and Institutional Memory pages.
category: devops
---

# Echopedia Homepage Curator

This skill powers the daily refresh of the Echopedia main page (`index.md`).

## Current Behavior (v1)

- Scans all person pages (`*-*.md`) in `/root/wiki-public/content`
- Ranks them by:
  - Total line count (depth)
  - Last modified time (recency)
- Selects the top 6 people pages
- Selects 4 strong institutional / project pages (hardcoded for v1)
- Updates the "Featured People" and "Featured Institutional Memory" sections in `index.md`
- Syncs the change to the deploy repo and pushes

Note: Repetition avoidance is intentionally disabled in v1 due to limited historical data.

## Files Modified

- `/root/wiki-public/content/index.md`
- `/root/wiki-deploy/content/index.md`

## Future Improvements (v2+)
- Add repetition avoidance using a "recently featured" log
- Add tag-based weighting
- Add LINE/Telegram notification after refresh
- Make institutional selection dynamic

## v1 Execution Workflow (discovered during live cron runs)
1. `find ... *-*.md` + python glob filter: exclude gstpc-*, echopedia-*, line-*, toward-*, good-shepherd-*, nechopedia-*, and any *society* or *historical-society* basenames. Additionally exclude any basename containing church, seminary, theological, tainan-, taiwan-, pasadena-, los-angeles-, irvine-, or residing under event/ subdirectories to ensure only true person pages are ranked.
2. For each candidate: parse YAML frontmatter (if present) to extract real `title:` for display names; fall back to filename slug.
3. Rank with `sort(key=lambda x: (-lines, -mtime))`; take top 6.
4. Rebuild the exact "Featured People" markdown list block (preserve any trailing notes like "— New TAHS volunteer member").
5. Apply identical targeted replace to BOTH `/root/wiki-public/content/index.md` and `/root/wiki-deploy/content/index.md`.
6. In wiki-deploy: `git add`, commit with conventional message, `git push origin $(git branch --show-current)` (master observed in practice).
7. Institutional section remains hardcoded in v1.

## Pitfalls
- Person pages often share the `*-*.md` glob with institutional content; naive ranking surfaces gstpc- and echopedia- files first — must filter aggressively.
- Frontmatter titles contain honorifics (Rev., Elder, Dr.) and parenthetical Chinese; always prefer parsed title over basename.
- wiki-deploy remote uses `master` branch (not main); always detect current branch before push.
- Both index.md files must stay byte-identical after update; run the same patch on both.
- Cron runs are silent unless content actually changed; only emit a report when Featured People list differs.

## Usage

This skill is designed to be called by a daily cron job (see `cronjob` configuration).