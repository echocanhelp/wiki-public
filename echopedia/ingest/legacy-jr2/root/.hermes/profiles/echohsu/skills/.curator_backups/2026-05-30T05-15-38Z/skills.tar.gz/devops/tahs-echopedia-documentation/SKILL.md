---
name: tahs-echopedia-documentation
description: Workflow for ingesting and publishing TAHS (Taiwanese American Historical Society) documents into Echopedia as a single consolidated page.
---

# TAHS Echopedia Documentation Workflow

## Core Rule
**Always consolidate TAHS governance, historical, and organizational documents into ONE single main page** for the society (`taiwanese-american-historical-society-台美人歷史協會.md`). Do not create separate pages for individual documents (roster, bylaws, IRS letters, action items, etc.).

## Naming Conventions
- All Chinese names **must** include both the original characters and romanized form.
- Example: 許景鴻 (Leonard Hsu Jr.)
- When the user provides an English name for a person, add it in parentheses after the Chinese name.

## Content Hygiene
- **Never publish personal contact information** (phone numbers, personal emails, home addresses) on public Echopedia pages.
- Remove any handwritten or printed phone numbers before publishing.

## Publishing Flow
1. Create/update the consolidated page in `/root/wiki-public/content/`
2. Copy the file to `/root/wiki-deploy/content/`
3. Commit with a clear message describing the documents added or corrections made
4. Push to the `wiki-public` repository

## Draft Page Policy (Updated 2026-05-28)
**Draft pages are intentionally published** for client review.  
- Do **not** rely on `Plugin.RemoveDrafts()` to hide draft content.
- Quartz config has `filters: []` so all pages (including `status: Draft`) appear on the live site.
- Use `status: Draft` only as an internal marker for the author — clients can still see and review the page.
- When ready for final release, change frontmatter to `status: Published`.

## Trigger Conditions
- User sends images or documents related to 台美人歷史協會 / TAHS
- User provides corrections to names or content on the society page
- User explicitly says "use the existing page" or similar consolidation instruction

## Pitfalls to Avoid
- Creating multiple separate pages for different TAHS documents
- Leaving personal phone numbers in published content
- Using only English names without the Chinese characters
- Forgetting to sync and push after editing the source file