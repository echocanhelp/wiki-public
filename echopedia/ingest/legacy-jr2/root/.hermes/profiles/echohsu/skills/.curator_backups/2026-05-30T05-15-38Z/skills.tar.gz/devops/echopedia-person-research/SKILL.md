---
name: echopedia-person-research
description: Research workflow for locating biographical and historical sources on Taiwanese American individuals for Echopedia person pages.
---

# Echopedia Person Research

## Core Principle
When researching Taiwanese or Chinese names for Echopedia, public web sources are often thin. Prioritize primary documents, community newsletters, and direct member knowledge over Google scraping.

## Chinese Name Search Method
**Never manually construct percent-encoded Google URLs** in browser tools. 
- Use raw Chinese characters with DuckDuckGo.
- Prefer `x_search` for social mentions.
- When the user provides search result text, treat it as authoritative source material.

## Naming Convention
- Always record both Chinese characters and romanized form.
- Preferred format: English (Chinese) or Chinese (Romanization)
- Example: Yang Chia-yu 楊嘉猷

## Source Prioritization
1. Primary documents (IRS letters, bylaws, organizational rosters)
2. Community event recordings and newsletters
3. Government service records (when available)
4. Contemporary news mentions

## Pitfalls
- Relying solely on Google results (frequently blocked or low yield)
- Publishing personal contact information
- Creating pages with only English names

## Related Skills
- tahs-echopedia-documentation (for society-level documents)
- tahs-member-onboarding (for new member intake)