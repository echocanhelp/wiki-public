---
name: kanban-special-profiles
description: "Handling Kanban tasks assigned to non-standard profiles (Imagine, video, TTS, or other specialized models) that are incompatible with normal worker runtimes."
version: 1.0.0
---

# Kanban + Special Profiles

## When to Use
- A task must be assigned to a profile whose model is not a standard chat/inference model (e.g. `grok-imagine-image-quality`, video generation, TTS-only, etc.).
- Worker crashes with "pid not alive" or similar when the profile is used as a Kanban assignee.

## Core Rules
1. **Check model type first** — Before creating a Kanban task, inspect the profile's `config.yaml` (`model.default` and `provider`). If it is an Imagine/video/TTS/specialized model, do **not** assign via Kanban by default.
2. **Prefer direct use** — For Imagine/video profiles, deliver the prompt directly to the user or use the native Imagine interface rather than routing through Kanban.
3. **Recovery pattern when corruption occurs**:
   - Delete `/root/.hermes/kanban.db`
   - Run `hermes kanban init`
   - Re-create only the necessary tasks

## Pitfalls
- Assigning an Imagine-specialized profile to Kanban almost always results in repeated worker crashes.
- Kanban DB corruption is a common side-effect of repeated failed claims.
- Reclaiming + blocking is only a temporary workaround — the profile must be fixed or the task reassigned.

## Recommended Workflow
1. Discover profile model with `hermes profile describe <name>` + `cat .../config.yaml`
2. If model is Imagine/video/TTS → do not create Kanban task
3. If task must be tracked → create it under a normal chat profile and note that the actual generation will be done manually or via direct prompt

## References
- See `references/audioforge-investigation.md` for the concrete case that triggered this skill.