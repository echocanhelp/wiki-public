# GSTPC Historical Bulletin Rollout Pattern

Use this reference when a source domain has long-running dated bulletin archives.

## Trigger
- User gives a concise command like `echopedia https://<domain>/home/`.
- Source contains multi-year bulletin/post archives.

## High-value output shape
1. Per-item bulletin pages (year-aware paths).
2. Historical signals index page (cross-year retrieval surface).
3. Domain page index page (hub for all generated pages).
4. Rollout tracker page (coverage and QA state).

## Minimum per-item fields to preserve
- Source title
- Source URL
- Capture date
- Extracted excerpt
- Optional structured hints (scripture refs, speaker/person names, signal notes)
- Cross-links to domain hub/index pages

## Publish QA (representative)
- Verify index pages return HTTP 200.
- Verify representative bulletin pages from non-adjacent years return HTTP 200 (e.g., current year, mid archive year, older year).
- Confirm cross-links between domain hub and historical index are live.

## Notes
- Prefer preserving provenance over aggressive summarization.
- For historical religious/community bulletins, extraction depth can be increased in later passes (sermon titles, scripture blocks, announcement categories, prayer themes) after baseline archive integrity is live.
