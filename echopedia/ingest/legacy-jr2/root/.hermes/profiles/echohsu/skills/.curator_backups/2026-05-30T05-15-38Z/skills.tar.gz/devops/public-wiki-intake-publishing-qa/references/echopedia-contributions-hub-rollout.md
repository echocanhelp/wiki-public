# Echopedia Contributions Hub Rollout Notes

## Durable patterns captured
- Authoring workspace can be non-git while deploy workspace is git-backed.
- Public intake hubs must only expose contributor-safe links.
- A Google Form setup doc is not a live intake endpoint.

## Practical verification sequence
1. Verify submit section includes public channels: form, email, LINE.
2. Confirm form URL shape is public (`forms.gle/...` or `/forms/d/e/.../viewform`).
3. Remove/avoid internal Google Docs/Sheets links from public page.
4. Commit/push from deploy repo, not non-git authoring workspace.
5. Validate rendered page and key intake links; if render lags, confirm raw repo content before further edits.

## Canonical public fallback language
- "If you cannot access Google Form, submit via email or LINE."