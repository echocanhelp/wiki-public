# audioforge Investigation (2026-05-29)

**Profile config:**
- model: grok-imagine-image-quality
- provider: xai-oauth

**Symptoms:**
- All Kanban tasks assigned to audioforge crashed with "pid not alive"
- 2–8 consecutive crashes per task
- Kanban DB became corrupt after repeated failed claims

**Root cause:**
The profile is configured for the specialized Grok Imagine image model, which is incompatible with the standard Kanban worker runtime.

**Lesson:**
Never assign Imagine/video/TTS-specialized profiles to Kanban. Use direct prompts or the native Imagine interface instead.